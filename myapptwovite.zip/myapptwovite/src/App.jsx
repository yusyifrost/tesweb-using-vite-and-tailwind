import React from "react";
import Applyone from "./components/Applyone";
import Applytwo from "./components/Applytwo";

function App() {
  var applyone = [
    {
      name: "Joe Taslim",
      job: "Actor",
      age: "36",
      origin: "Indonesia",
    },
  ];

  return (
    <div className="h-800 p-4 justify-center py-10 bg-pink-200 bg-gradient-to-r from-buttercup-200 ">
      {applyone.map((data, index) => (
        <Applyone data={data} key={index} />
      ))}
      <div className="flex items-center justify-center h-screen">
        <Select class="bg-white">Select</Select>
      </div>
    </div>
  );
}

export default App;
