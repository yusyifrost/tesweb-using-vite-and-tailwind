import React from "react";
import ReactDOM from "react-dom/client";

import App from "./App";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./index.css";
import DetailScreen from "./pages/DetailScreen";
import ListAtt from "./pages/ListAttend";
import MasterPage from "./pages/MasterPage";
import MasterPage2 from "./pages/MasterPage2";
import SignInScreen from "./pages/SignInScreen";
import ListAttend from "./pages/ListAttend";
import ListAtt2 from "./pages/ListAtt2";
import BlogSections from "./pages/BlogSections";
import Division from "./pages/Division";

const router = createBrowserRouter([
  {
    path: "/",
    element: <MasterPage />,
    children: [
      {
        path: "blogsections",
        element: <BlogSections />,
      },
      {
        path: "test",
        element: <App />,
      },
      {
        path: "listattend",
        element: <ListAttend />,
      },
      {
        path: "/listatt2",
        element: <ListAtt2 />,
      },
      {
        path: "/division",
        element: <Division />,
      },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <RouterProvider router={router} />
);
