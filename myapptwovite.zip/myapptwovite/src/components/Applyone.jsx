import React from "react";

export const Applyone = ({ data }) => {
  return (
    <div className="container mb-5 sm:mb-0 ml-5 sm:ml-0 mr-5 p-5 rounded-xl">
      <div className="flex space-x-4 flex-row">
        <div></div>
        <div className="container p-5 h-100 w-42 rounded-xl  bg-300 gap-5 ml-5 class=grid grid-rows-2 grid-flow-col gap-4">
          <div className="flex space-x-4 flex-row">
            <div class="bg-white h-20 w-20 rounded-full p-4 border-double border-4 border-purple-600"></div>
            <div class="p-2">
              <h6 class="text-white text-bold">{data.name}</h6>
              <span class="text-white">{data.job}</span>
            </div>
          </div>
          <div className="  w-42 h-60 mt-5 rounded-lg p-4 grid grid-cols-3 gap-2">
            <div className="hover:scale-110 duration-150 border-2 border-white h-28 w-48 p-2 bg-gradient-to-r from-purple-800 bg-fuchsia-300 rounded-lg text-white text-sm">
              Lokasi : Jakarta
            </div>
            <div className="hover:scale-110 duration-150 border-2 border-white h-28 w-48 p-2 text-white text-sm bg-gradient-to-r from-purple-800 bg-fuchsia-300 rounded-lg">
              Tujuan Kunjungan :
            </div>
            <div className="hover:scale-110 duration-150 border-2 border-white h-28 w-48 p-2 text-white text-sm bg-gradient-to-r from-purple-800 bg-fuchsia-300 rounded-lg">
              Person :
            </div>
          </div>
          <div class="relative h-32 w-32">
            <button class=" transition ease-in-out delay-150 bg-slate-700 bg-gradient-to-r via-cyan from-fuchsia-800 hover:scale-110 hover:bg-pink-600 duration-300 outline outline-offset-2 outline-purple-500 bottom-0 text-center text-white text-semibold p-5 mr-5 ml-96 h-12 w-20 p-2 rounded-lg bg-green-300">
              Edit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Applyone;
