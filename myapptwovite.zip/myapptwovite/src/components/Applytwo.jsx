import React from "react";

function Applytwo() {
  return (
    <div className="h-60 w-32 rounded-xl pl-10 pr-10 pt-5 pb-5  gap-5 border-2 border-white text-white">
      <div className="hover:scale-110 duration-150 hover:font-bold">Menu</div>
      <div className="hover:scale-110 duration-150 hover:font-bold">
        Absensi
      </div>
      <div className="hover:scale-110 duration-150 hover:font-bold">
        Histori Absensi
      </div>
      <div className="hover:scale-110 duration-150 hover:font-bold">Akun</div>
      <div className="hover:scale-110 duration-150 hover:font-bold">
        Setting
      </div>
    </div>
  );
}

export default Applytwo;
