import React from "react";
import ButtonSelect from "ButtonSelect";

const ButtonSelect = () => {
  return (
    <button class="flex flex-row items-center transition duration-300 ease-in-out bg-blue-200 bg-gradient-to-r from-purple-800 text-white hover:bg-blue-800 active:bg-blue-700 focus:outline-none focus:ring focus:ring-blue-300 rounded-lg md:text-center p-2 -mb-10">
      Select
      <ArrowRightIcon className="w-5 h-5 text-white " />
    </button>
  );
};
