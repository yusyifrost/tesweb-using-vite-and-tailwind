import { Fragment, useState } from "react";
import { Dialog, Transition } from "@headlessui/react";
import {
  Bars3Icon,
  CalendarIcon,
  HomeIcon,
  MagnifyingGlassCircleIcon,
  MapIcon,
  MegaphoneIcon,
  UserGroupIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { Outlet } from "react-router-dom";

const navigation = [
  { name: "Dashboard", href: "/blogsections", icon: HomeIcon, current: true },
  { name: "Staff", href: "/listattend", icon: UserGroupIcon, current: false },
  {
    name: "Attendance",
    href: "/listatt2",
    icon: MagnifyingGlassCircleIcon,
    current: false,
  },
  { name: "Announcements", href: "#", icon: MegaphoneIcon, current: false },
  { name: "Division", href: "/division", icon: MapIcon, current: false },
  {
    name: "Attendance History",
    href: "#",
    icon: CalendarIcon,
    current: false,
  },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}

export default function MasterPage() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <>
      {/*
        This example requires updating your template:

        ```
        <html class="h-full bg-white">
        <body class="h-full overflow-hidden">
        ```
      */}
      <div className="flex h-full">
        {/* Static sidebar for desktop */}
        <div className=" lg:flex lg:flex-shrink-0">
          <div className="flex w-64 flex-col">
            {/* Sidebar component, swap this element with another sidebar if you like */}
            <div className="flex min-h-0 flex-1 flex-col border-r border-gray-200 bg-buttercup-600 text-white">
              <div className="flex flex-1 flex-col overflow-y-auto pt-5 pb-4">
                <div className="flex flex-shrink-0 items-center px-4">
                  <div>
                    <img
                      className="inline-block h-9 w-9 rounded-full"
                      src="https://images.unsplash.com/photo-1517365830460-955ce3ccd263?ixlib=rb-=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=8&w=256&h=256&q=80"
                      alt=""
                    />
                  </div>
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-white-700 group-hover:text-gray-900">
                    Whitney Francis
                  </p>
                  <p className="text-xs font-medium text-white-500 group-hover:text-gray-700">
                    View profile
                  </p>
                </div>
                <nav className="mt-5 flex-1" aria-label="Sidebar">
                  <div className="space-y-1 px-2">
                    {navigation.map((item) => (
                      <a
                        key={item.name}
                        href={item.href}
                        className={classNames(
                          item.current
                            ? "bg-buttercup-400 text-white-900"
                            : "text-white-600 hover:bg-buttercup-200 hover:text-gray-900",
                          "group flex items-center px-2 py-2 text-sm font-medium rounded-md"
                        )}
                      >
                        <item.icon
                          className={classNames(
                            item.current
                              ? "text-gray-500"
                              : "text-gray-400 group-hover:text-gray-500",
                            "mr-3 h-6 w-6"
                          )}
                          aria-hidden="true"
                        />
                        {item.name}
                      </a>
                    ))}
                  </div>
                </nav>
              </div>
              <div className="flex flex-shrink-0 border-t border-gray-200">
                <a href="#" className="group block w-full flex-shrink-0">
                  <div className="flex items-center"></div>
                </a>
              </div>
            </div>
          </div>
        </div>
        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          <Outlet />
        </div>
      </div>
    </>
  );
}
