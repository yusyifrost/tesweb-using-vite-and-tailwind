/** @type {import("tailwindcss").Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./pages/**/*.{html,js}",
    "./components/**/*.{html,js}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#10B981",
          50: "#8CF5D2",
          100: "#79F3CB",
          200: "#53F0BC",
          300: "#2EEDAE",
          400: "#13DF9B",
          500: "#10B981",
          600: "#0C855D",
          700: "#075239",
          800: "#031E15",
          900: "#000000",
        },
        buttercup: {
          DEFAULT: "#F59E0B",
          50: "#FFFFFF",
          100: "#FFFBF6",
          200: "#FCE4BB",
          300: "#FACD81",
          400: "#F7B546",
          500: "#F59E0B",
          600: "#D98B09",
          700: "#BB7808",
          800: "#9E6506",
          900: "#805305",
        },
      },
    },
  },
  plugins: [],
};
